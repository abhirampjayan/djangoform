from django.apps import AppConfig


class FakeConfig(AppConfig):
    name = 'fake'
